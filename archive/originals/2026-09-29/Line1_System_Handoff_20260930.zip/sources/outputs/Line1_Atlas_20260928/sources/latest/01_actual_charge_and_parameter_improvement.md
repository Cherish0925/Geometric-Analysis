# 第一卷：实际电荷、集中模型与参数间隙加强

Research snapshot: 0b1490791be560203b86a7d9834dcdc3cbc83b41.

I50—I51全文。前稿的高指数局部模型由后稿继续检验延拓代价。局部实际可解、闭流形上的完整实际供给、无条件零端间隙不是同一结论。

Read 00_READ_FIRST.md for superseded statements. Each source below is complete and byte-preserved. Original local links remain relative to their source; locate other texts using 10_source_map_and_history.md. Formula numbers restart in each source.


---

## Source 1: 20260927_marked_charge_and_first_order_flux.md

Original path: `continuation/20260927_marked_charge_and_first_order_flux.md`

SHA-256: `50e7513fccda7376e0c05c24073717e82d77ee5a72f172ba134667bf9ba6fbe1`

BEGIN COMPLETE SOURCE

# Marked determinant charge and signed first-order cost

27 September 2026. Continues `fbe5404` and the I40--I49 proofs.
The external reviews are preserved under `guidance/source/`; their proposed
general no-loss theorem is a research target, not a premise here.

The new connection is between a marked **whole smooth core** and the actual
determinant connection, without requiring a nonzero spinor inside the rescaled
core. Its relative charge is controlled at every finite tree depth. This is
not yet control of the opposite-spinor second Chern number: an explicit
classical family distinguishes those charges. A separate signed localization
below identifies the flux needed to improve the balanced small-h coefficient.

## 1. A marked determinant atom

Use the complex (physical) orientation of
\(\Gamma_n=\frac1n(1,-2)\), where \(n=2k+1\ge3\). The generator acts as
\((z_1,z_2)\mapsto(\zeta z_1,\zeta^{-2}z_2)\). Put

\[
 f_n=\frac{k}{2k+1}=\frac{n-1}{2n}\in[1/3,1/2).
 \tag{1.1}
\]

Let \(\Omega\) be a compact oriented smooth four-manifold with this single
marked boundary. Let \(L\) be a Hermitian line bundle whose boundary flat
character, in this marking, is \(\zeta\) or \(\zeta^{-1}\). No topology or
metric restriction is imposed on the interior. Write \(F_A=i\omega_A\), with
\(\omega_A\) real, for a unitary connection.

### 1.1. The relative square and its sign

The minimal resolution has intersection matrix \(Q_k\) with diagonal
\((-2,\ldots,-2,-3)\) and adjacent off-diagonal entries 1. Its anticanonical
class evaluates as \((0,\ldots,0,-1)\); its boundary character is
\(\zeta^{-1}\). Inverting the last column gives

\[
 (Q_k^{-1})_{ik}=-\frac{i}{2k+1},\qquad
 (Q_k^{-1})_{kk}=-f_n.
 \tag{1.2}
\]

Indeed the interior recurrence is \(x_{i-1}-2x_i+x_{i+1}=0\), with
\(x_0=0\) and \(x_{k-1}-3x_k=1\). The inverse line has the same square.
Glue an arbitrary same-marked filling to the reversed resolution, matching
the flat boundary connections. The resulting closed line bundle has integral
first-Chern square. Consequently, if \(A\) is flat on a boundary collar,

\[
 q_A:=\frac1{4\pi^2}\int_\Omega\omega_A\wedge\omega_A
                  \in\mathbb Z-f_n.
 \tag{1.3}
\]

The statement uses the actual character, not just that it is faithful. A
different character can have a different fractional square.

For a general boundary connection let \(A_0\) be the flat connection on the
same boundary line. Write \(A=A_0+ia\) there and set

\[
 b_A(Y)=\frac1{4\pi^2}\int_Y a\wedge da,
 \qquad q_A^{\rm rel}=q_A-b_A(Y).
 \tag{1.4}
\]

These quantities are unambiguous: \(H^1(Y;\mathbb R)=0\), so changing the
flat reference or gauge changes \(a\) by an exact form and does not change
the integral. Flatten the connection near the boundary, or use the abelian
transgression \(d(a\wedge da)=da\wedge da\), to obtain

\[
 \boxed{q_A^{\rm rel}\in\mathbb Z-f_n,\qquad
 |q_A^{\rm rel}|\ge f_n.}
 \tag{1.5}
\]

Boundary orientation is outward throughout. In particular, the flat-collar
template satisfies

\[
 \boxed{\int_\Omega|F_A|^2\ge4\pi^2 f_n
             =2\pi^2\frac{n-1}{n}\ge\frac{4\pi^2}{3}.}
 \tag{1.6}
\]

This is a characteristic-number energy bound, not an SW existence theorem.
An actual positive-weight SW solution with identically flat determinant
connection on an open collar would have zero spinor there. The application
therefore uses the general-boundary estimate below, not a flat actual collar.

### 1.2. Arbitrary actual connection on a controlled geometric collar

Suppose an outer collar is identified with
\([r,2r]\times S^3/\Gamma_n\), with its metric uniformly bilipschitz to the
Euclidean annulus and its radial coarea factors uniformly comparable. The
comparison constant is fixed; \(r\), \(n\), interior geometry and internal
scale separation are unrestricted.

For every smooth level \(Y_s\), take the round Coulomb primitive of the
restricted curvature. On the unit round quotient, the relevant positive
Hodge spectrum is bounded below by that of \(S^3\): lift to invariant forms,
solve on \(S^3\), and descend. Thus the constant is independent of \(n\).
Scaling and metric comparison give

\[
 \|a\|_{L^2(Y_s)}\le Cr\|F_A|_{Y_s}\|_{L^2(Y_s)},\qquad
 |b_A(Y_s)|\le Cr\int_{Y_s}|F_A|^2.
 \tag{1.7}
\]

Coarea supplies a level with

\[
 |b_A(Y_s)|\le C\int_{\text{collar}}|F_A|^2.
 \tag{1.8}
\]

Let \(\Omega_s\) be the whole region inside that level and let
\(\widehat\Omega\) include it and the collar. Combining (1.4), (1.8) and
\(|\omega_A\wedge\omega_A|\le|F_A|^2d\mu\) proves

\[
 \boxed{f_n\le |q_A^{\rm rel}(\Omega_s)|
               \le C\int_{\widehat\Omega}|F_A|^2.}
 \tag{1.9}
\]

The relative number is independent of the selected level. No smallness of
the connection, no gauge equation and no field-amplitude premise is required
for (1.9). The geometric collar, marked character and whole filling are
essential hypotheses. A terminal punctured region does not meet them.

### 1.3. Sharpness of the flat comparison template

[Calderbank--Singer, Theorem A](https://arxiv.org/html/math/0206229) supplies
scalar-flat Kähler ALE metrics on the minimal resolution. Their canonical
determinant curvature is anti-self-dual in the physical orientation, has
relative square \(-f_n\), and hence has energy exactly \(4\pi^2f_n\).
Truncate sufficiently far out and flatten the decaying connection to its
flat reference over the outer annulus. The extra energy tends to zero.
If desired, flatten the metric collar as in I47. Homothety does not change
the four-dimensional curvature-square energy. Therefore

\[
 \inf_{\text{flat-collared marked smooth fillings}}
                   \int|F_A|^2=4\pi^2 f_n.
 \tag{1.10}
\]

This invokes a classical construction; it is not a new ALE metric or a
closed actual zero-end escape sequence.

## 2. Actual determinant charge is tight on small-volume marked cores

Retain the actual finite-pencil input and class-square hypothesis of
[I41, Sections 6--7](20260927_conformal_separation_and_zero_end.md).
For \(\beta\ge4\) and \(0<\eta\le1\), write

\[
 \eta=\kappa_\beta+\varepsilon,\qquad
 \epsilon_*=\beta^{-1}+\sqrt\eta.
\]

The positive determinant fit and the negative determinant saturation give
bounded two-form models \(K_+,K_-\) with

\[
 \|K_+\|_\infty+\|K_-\|_\infty\le C,\qquad
 \int(|F_A^+-K_+|^2+|F_A^--K_-|^2)\le C\epsilon_*V.
 \tag{2.1}
\]

Equivalently for the present purpose, there is a positive measure \(\nu\)
such that

\[
 |F_A|^2d\mu\le C\,d\mu+\nu,\qquad
                        \nu(M)\le C\epsilon_*V.
 \tag{2.2}
\]

This follows pointwise from the squared distance to the bounded models.
It is normalized-volume tightness, not local scale-invariant regularity.

Let \(\widehat\Omega_i\) be any finite collection of the marked whole-core
regions of Section 1.2 with overlap at most \(\Lambda\). Put
\(Q_i=q_A^{\rm rel}(\Omega_i)\). Summing (1.9) and (2.2) yields

\[
 \boxed{\frac1V\sum_i|Q_i|
 \le C\frac{\sum_i\operatorname{Vol}(\widehat\Omega_i)}V
                          +C\Lambda\epsilon_*,
 \qquad \frac N3\le\sum_i|Q_i|.}
 \tag{2.3}
\]

In a zero-end sequence, bounded overlap and total core volume \(o(V)\)
therefore force the **absolute relative determinant-charge density**, not
just the number density, to tend to zero. No nonzero rescaled spinor in a
core is assumed. The actual line and its boundary marking are retained.

Alternatively suppose each enlarged core has volume at most a sufficiently
small fixed \(v_*\). The volume term in the unnormalized (2.3) is at most
\(CNv_*\), and can be absorbed using \(N/3\le\sum_i|Q_i|\). Thus

\[
                        N/V\le C\Lambda\epsilon_*.
 \tag{2.4}
\]

For **absolute** exclusion of every such core, one needs the corresponding
absolute error tending to zero; for example, total core volume tending to
zero and \(\epsilon_*V\to0\). Normalized estimates alone do not give that.

### 2.1. What survives an arbitrarily deep finite decomposition

For a region with one outer and several inner marked boundaries define the
following quantity. Each inner boundary is oriented outward from the removed
**child core**, opposite to its induced boundary orientation in the region:

\[
 Q_A(W)=\frac1{4\pi^2}\int_W\omega_A\wedge\omega_A
          -b_A(Y_{\rm out})+\sum b_A(Y_{\rm in}).
 \tag{2.5}
\]

Matched restrictions of the **same actual connection** give exact
additivity when pieces are glued. Internal boundary terms cancel before
absolute values are taken. A one-child flat neck can have zero charge and
zero energy; do not charge it as if it were a smooth cap.

Apply (2.3) to a disjoint frontier of whole subtrees, not to every nested
vertex. Its constant is independent of tree depth. A sequence of finite
trees of unbounded depth therefore obeys the same frontier estimate. This
is a proved depth-independent accounting result **given** those marked
regions. It does not construct a bubble tree from weak integral input, nor
license an infinite unsigned sum over overlapping ancestors.

More explicitly, set \(\phi_e=b_e-f_{n_e}\) at every marked interface. A
shell with outgoing edge \(e_0\) and incoming edges \(e_1,\ldots,e_s\)
satisfies

\[
 q_A(W)=m_W+\phi_{e_0}-\sum_{a=1}^s\phi_{e_a},\qquad m_W\in\mathbb Z.
 \tag{2.6}
\]

Sum this identity over any finite retained tree. Only its outer root and
unresolved frontier remain. Equations (1.8), (2.2), and (2.3) bound the
**absolute** sum of frontier \(b_e\), \(f_{n_e}\), and hence \(\phi_e\)
by \(o(V)\) when the frontier whole cores have total volume \(o(V)\).
They also control integer charges: if \(Q_i=m_i-f_{n_i}\), then
\(|m_i|\le2|Q_i|\). This supplies the limiting estimate beyond formal
finite-tree cancellation.

### 2.2. The same relative charge in the actual harmonic class

Let \(\mathcal H_A=2\pi i\,a_g^{\rm h}\) be harmonic curvature on the
**same integral determinant line**, including its torsion restriction, and
let \(J_+=\|F_A^+\|_2^2-4\pi^2p\). The supplied actual-field estimates
give \(J_+\le C\eta V\). Hodge orthogonality and Stokes imply

\[
 \boxed{\|F_A^\pm-\mathcal H_A^\pm\|_2^2=J_+,\qquad
              \|F_A-\mathcal H_A\|_2^2=2J_+.}
 \tag{2.7}
\]

Indeed the difference is exact, say \(i\,d\alpha\), and
\(\int d\alpha\wedge d\alpha=0\). Its two chiral energies agree.
Combining (2.1) and (2.7) gives the same measure majorant and setwise
tightness for \(\mathcal H_A\) as for \(F_A\).

If two connections on this line differ by \(i\alpha\), the change of
\(\int\omega_A\wedge\omega_A\) is the boundary integral of
\(2\alpha\wedge\omega_A+\alpha\wedge d\alpha\). This is precisely the
change of the boundary expression in (1.4). Therefore

\[
            q_{A_{\rm h}}^{\rm rel}(\Omega_i)=q_A^{\rm rel}(\Omega_i).
 \tag{2.8}
\]

There is no estimate for the global primitive \(\alpha\), nor any use of
a first eigenvalue bound. The equality is topological; the energy control
comes from (2.7). Replacing the integral line by only its real cohomology
vector would lose the torsion boundary marking and is not permitted.

### 2.3. Density in the original budget

Now assume \(p\ge A>0\) and \(\chi(M)/A\le B\). At small Ricci residual
\(r=\fint|\operatorname{Ric}+g|^2\), Chern--Gauss--Bonnet yields

\[
 \frac{8\pi^2\chi}V\ge
 \frac{(4-2\sqrt r)^2}{24}-\frac r2
                 =\frac23-\frac23\sqrt r-\frac r3.
 \tag{2.9}
\]

Here \(\fint(s+4)^2\le4r\) and
\(\fint|\operatorname{Ric}^{\circ}|^2\le r\). For \(r\le1/4\), (2.9)
gives \(V/A\le32\pi^2B\). Positive determinant saturation gives
\(p/V\to2/(9\pi^2)\) at the endpoint. Consequently

\[
 \frac{9\pi^2}{2}(1+o(1))\le\frac VA
                         \le12\pi^2B(1+o(1)).
 \tag{2.10}
\]

In particular (2.3) is also an \(o(A)\) charge statement. The same Euler
identity bounds the total \(W^-\) energy by \(C(B)V\), hence the curvature
energy of \(E_-=S^-\otimes L\) by \(C(B)V\). None of this gives local
noncollapse or a quartic derivative bound for the torsion field.

## 3. The determinant charge does not control the torsion index

The distinction can be made exact. Now additionally assume a Spin-c structure
on the entire filling with determinant \(L\), extending the specified boundary
lift. An arbitrary line bundle from Section 1 need not be such a determinant.
In an exactly flat-conical comparison collar with the two
allowed parallel boundary spinors, let \(J_+\) be the relative second Chern
number of \(S^+\), and \(J_-\) that of \(S^-\otimes L\), using these boundary
sections. Write

\[
 q_A^{\rm rel}=m-f_n,\quad
 B_n=\frac{5-n}{2}+f_n,\quad
 j=2\chi(\Omega)+3\tau(\Omega)-\frac{5-n}{2}.
 \tag{3.1}
\]

Both \(m,j\) are integers. The spinor characteristic identities, together
with the outward cone Gauss--Bonnet boundary term \(1/n\), give

\[
 \boxed{J_+=\frac{m-j}{4},\qquad
        J_--J_+=2q_A^{\rm rel}+\chi(\Omega)-\frac1n
                    =\chi(\Omega)-1+2m.}
 \tag{3.2}
\]

For the first formula, \(4c_2(S^+)=c_1(L)^2-(p_1+2e)\) and the integrated
last parenthesis is \(2\chi+3\tau-B_n=j-f_n\). For the second, the exact
characteristic-form identity is
\(c_2(S^-\otimes L)-c_2(S^+)=2c_1(L)^2+e\).
The parallel boundary references have zero transgression. These derivations
also specify the sign and the necessary congruence \(m\equiv j\pmod4\).

On the canonical minimal-resolution models used in (1.10),

\[
 \chi=k+1,\quad\tau=-k,\quad m=j=J_+=0,
 \qquad J_-=k=\frac{n-1}{2},\qquad
 |q_A^{\rm rel}|=f_n<\frac12.
 \tag{3.3}
\]

Thus even a zero positive-spinor relative index and uniformly bounded
determinant energy do not bound the opposite-spinor index. The latter grows
without bound. Actual nonparallel boundary sections can additionally carry
integer homotopy defects; they must be tracked rather than silently replaced
by the flat references.

Consequently (2.3) cannot alone eliminate the order-V signed torsion flux
forced by the actual zero-end identities. One needs actual control of that
index or flux, a uniform charge-per-core bound, or a different direct PDE
argument. The classical model proves this limitation of a proposed **charge
comparison**, not existence of a closed zero-end counterexample.

### 3.1. An actual relative-index escape criterion

The existing zero-end identities give

\[
 \frac{c_2(E_-)[M]}V
   =\frac1{8\pi^2V}\int|W^-|^2
                      +\frac5{12\pi^2}+O(\epsilon_*).
 \tag{3.4}
\]

Suppose **disjoint** marked whole cores contain all zeros of the actual
cubic torsion \(t_\Phi\), which is nonzero on their boundaries. Let
\(\nu_i\) be the relative second Chern index defined by this actual boundary
section, not by a reference parallel spinor. Excision then gives
\(\sum_i\nu_i=c_2(E_-)[M]\). Bounded overlap alone would not justify this
index identity.

If their total volume is \(o(V)\), (2.3) implies, for every fixed \(L_0\),

\[
 \frac1V\sum_{\nu_i^+\le L_0|Q_i|}\nu_i^+\longrightarrow0.
 \tag{3.5}
\]

Thus macroscopic positive torsion index must occur at unbounded
\(\nu_i^+/|Q_i|\), or outside this proposed marked-core cover. Equation
(3.3) shows why topology alone does not bound that ratio.

There is also an **actual local gauge** reason not to impose a universal
index/charge comparison on arbitrary cores. In the existing hyperbolic
ball construction of [I41, Section 15.1](20260927_conformal_separation_and_zero_end.md),
the determinant line is trivial, so Stokes gives exactly
\(q_A^{\rm rel}=0\). The actual cubic torsion has relative index \(+1\),
and \(\int|F_A|^2=O(\varepsilon^4)\). Ricci and Weyl errors vanish on
that ball. Its boundary winding and large outgoing derivative still have
to be matched to an exterior. The normalized full form defect on the
shrinking ball was not shown to tend to zero. This is a local obstruction
to a charge-only argument, not a closed O10 counterexample.

### 3.2. Actual hyperbolic cores with unbounded torsion index

The preceding local obstruction extends beyond a single unit of charge.
It can carry arbitrarily large index on the same ball topology, with a
uniformly nonzero torsion field on a **round fixed-ratio collar**.

**Proposition (high-index local actual fields).** Fix a hyperbolic metric
with sectional curvature \(-1/3\) and a point. For every integer \(d\ge1\)
and sufficiently small \(\varepsilon>0\), there is a smooth actual solution
on the physical ball \(B_{2\varepsilon}\), on its trivial determinant line,
such that

\[
 D_A\Phi=0,\qquad F_A^+=2i\sigma(\Phi),\qquad
 |\Phi|^2=\frac43+O_d(\varepsilon^2).
 \tag{3.6}
\]

On every round sphere of radius \(s\varepsilon\), \(1\le s\le3/2\), its
cubic torsion is nonzero and has relative index \(d^2\). The relative
determinant square is zero. Uniformly over these radii,

\[
 \int_{Y_{s\varepsilon}}G=-d^2+O_d(\varepsilon^4),
 \qquad q_A^{\rm rel}=0.
 \tag{3.7}
\]

Here \(G\) is the fixed torsion-cutoff transgression of Section 5, which
equals the full unit-section transgression throughout that collar.

**Construction.** Use the Clifford frame and curved right inverses of
I41 Section 15.1. In rescaled coordinates \(x=\varepsilon y\), set

\[
 a^2=4/3,\quad c_d=2^{(d-1)/2},\quad
 g_d(z)=\frac{c_d}{2(d+1)}
              (\bar z_1^{d+1}-\bar z_2^{d+1}),\quad
 \Phi_0=a e_1+\varepsilon g_d e_2.
 \tag{3.8}
\]

The antiholomorphic coefficient has \(D_0^+(0,g_d)=0\). Direct substitution
in the cubic torsion formula gives, in physical derivative normalization,

\[
 t_0(\varepsilon y)=a^2c_d(\bar z_1^d,\bar z_2^d).
 \tag{3.9}
\]

Indeed the components are \(a^2(g_1+ig_2,-g_3-ig_4)\); the terms involving
\(\varepsilon g_d\) cancel by the same antiholomorphic Dirac equations.

For each fixed \(d\), the pulled-back rescaled metric is Euclidean plus
\(O(\varepsilon^2)\) in every fixed differentiability norm. The Dirichlet
right inverses \(R_D,R_A\) used in the earlier construction are uniformly
bounded for small \(\varepsilon\). First correct the seed by
\(-R_DD_\varepsilon^+\Phi_0=O_d(\varepsilon^2)\). Then apply the contraction

\[
 A(\Phi)=R_A(0,2\sqrt2\,i\varepsilon^2\sigma(\Phi)),\qquad
 \Phi=\widehat\Phi_0-\tfrac12R_D[c(A(\Phi))\Phi].
 \tag{3.10}
\]

On a fixed \(C^{k,\alpha}\) neighborhood, \(k\ge3\), its Lipschitz constant
is \(O_d(\varepsilon^2)\). It gives a smooth exact solution with
\(A_y=O_d(\varepsilon^2)\) and
\(\Phi-\Phi_0=O_d(\varepsilon^2)\), and hence

\[
 t(\varepsilon y)=a^2c_d(\bar z_1^d,\bar z_2^d)+O_d(\varepsilon)
                                                \quad\hbox{in }C^1.
 \tag{3.11}
\]

Constants may depend on \(d\). Boundary values are outputs of the
construction; they have not been prescribed as gluing data.

Since
\(c_d^2(|z_1|^{2d}+|z_2|^{2d})\ge|y|^{2d}\), the actual torsion has
\(|t|\ge a^2/2\) on \(1\le|y|\le3/2\), for sufficiently small
\(\varepsilon\). Its squared norm is at least \(4/9\), exceeding the
cutoff threshold \(m_\beta/8\le16/81\). Thus \(\theta=1\) on that whole
collar, for every \(\beta\ge4\).

The map \((\bar z_1^d,\bar z_2^d)\) has real degree \(+d^2\): the
holomorphic power map has degree \(d^2\), and conjugation on two complex
coordinates preserves real orientation. Boundary nonvanishing and the
small perturbation preserve this degree on every indicated sphere.
Interior zeros may split or be nontransverse; no unique-zero assertion is
needed for the relative index. Curvature of \(E_-\) is \(O_d(1)\) in
physical norms, so
\(\int_{B_{s\varepsilon}}c_2(E_-)=O_d(\varepsilon^4)\). The relative Chern
formula proves (3.7). The determinant equality in (3.7) is exact Stokes
on a trivial line, independently of any norm estimate.

The construction and exact torsion equation also give

\[
 \begin{split}
 \int(|\nabla_A^2\Phi|^2+|\nabla t|^2)&=O_d(\varepsilon^2),\\
 \int(|F_A|^2+|\nabla_A\Phi|^4+|t|^4)&=O_d(\varepsilon^4),\\
 \int(|\langle\Phi,\nabla_A\Phi\rangle|^2+|D_{3A}^-t|^2)
                                             &=O_d(\varepsilon^6).
 \end{split}
 \tag{3.12}
\]

For the last estimate, the current is \(O_d(\varepsilon)\), the spinor
derivative is \(O_d(1)\), and the actual torsion Dirac identity cancels the
scalar/model terms; \(W^+=0\) here. Ricci and Weyl errors vanish exactly
because the physical metric is the fixed hyperbolic metric.

Choose \(\varepsilon_d\) diagonally, after fixing \(d\), so all costs in
(3.12) tend to zero and the boundary degree and cutoff estimates hold.
Then \(\nu=d^2\to\infty\), while the displayed absolute subcritical costs
vanish. There is no claim of a uniform-in-d implicit-function radius.

The missing critical direction cost is visible explicitly. For the unit
seed \(u_d=t_0/|t_0|\), polar coordinates give

\[
 \frac{d^2}{r^2}\le|du_d|^2\le\frac{4d^2}{r^2}
                   \quad(1\le r\le3/2).
 \tag{3.13}
\]

The phase contribution is
\(d^2(x^{d-1}+y^{d-1})/(r^2(x^d+y^d))\), where
\(x=\cos^2\vartheta\), \(y=\sin^2\vartheta\). It lies between
\(d^2/r^2\) and \(2d^2/r^2\). The remaining angular derivative is bounded
by \(d^2/r^2\): its ratio to this bound is
\((xy)^{d-1}/(x^d+y^d)^2\le1\).
For example write \(x/y=z^2\); the last inequality follows from
\((z^{d-1}-1)(z^{d+1}-1)\ge0\), using \(x+y=1\).
The phase upper bound follows from
\((x-y)(x^{d-1}-y^{d-1})\ge0\). Endpoint values follow by continuity.
The displayed upper bound is deliberately relaxed.
For each fixed \(d\), (3.11) transfers these estimates to the actual unit
field after decreasing \(\varepsilon\). The diagonal can therefore retain

\[
 \int_{\varepsilon_d\le r\le3\varepsilon_d/2}|\nabla u|^4
                    \asymp d^4\longrightarrow\infty,
 \quad
 \int_{\varepsilon_d\le r\le3\varepsilon_d/2}|\nabla u|^2
                    \asymp\varepsilon_d^2d^2\longrightarrow0.
 \tag{3.14}
\]

This disproves a local signed-flux bound based only on the displayed
subcritical budgets, even with actual gauge equations and a nonzero fixed-ratio
torsion collar. It does **not** supply a fully calibrated endpoint collar:
torsion length has large radial/angular variation, and the ASD determinant
fit to the required exterior fails. There is no closed conformal supplier,
global class-square budget, or exterior matching. It is not an O10
counterexample, nor a sharpness example for the frontier exponent in (5.5).

## 4. Where a smaller balanced first-order coefficient must be paid

This section concerns the established **balanced surgery family**, not the
zero-end weighted solution. Let

\[
 M=X\#k\overline{\mathbb {CP}}^{\,2}
       \#\ell(S^1\times S^3),\quad A=c_1^2(X),\quad
 h=(k+4\ell)/A\to0,\quad U=1+h+O(h^2).
 \tag{4.1}
\]

Use a scalar-minus-four metric and one actual **ordinary**, unweighted SW
solution \((A_{\rm conn},\Phi)\) supplied by the specified class with
\(a^2=A-k\) and \(p=(a_g^+)^2\ge A\). The symbol \(A\) without a subscript
continues to denote the topological budget, not the connection. In the
formulas below \(F_{A_{\rm conn}}\) is abbreviated to \(F_A\).
All fields and remainders in this section belong to this same solution.

Put

\[
 \rho=|\Phi|^2\le4,\quad P=\int|\operatorname{Ric}^{\circ}|^2,
 \quad R=P+4V,\quad \mathcal E=4P/R,
 \quad J=\|F_A^+-(F_A^+)_H\|_2^2.
\]

The actual input and Hodge identities give

\[
 c_2(S^+)[M]=\ell,\qquad
 B:=\int|F_A^-|^2=4\pi^2(p-A+k)+J.
 \tag{4.2}
\]

Choose a fixed smooth increasing \(v(\rho)\) equal to zero for
\(\rho\le1/2\), one for \(\rho\ge1\), with \(|v'|\le4\), and put
\(\chi=(1-v)^2\). Write \(T_u\) for the exact rank-two transgression on
\(u=\Phi/\sqrt\rho\), as in I40 Section 1, and define

\[
 q_\chi=\int d\chi\wedge T_u,\quad
 P_\chi=\int\chi|\operatorname{Ric}^{\circ}|^2,\quad P_o=P-P_\chi,
 \quad B_\chi=\int\chi|F_A^-|^2,\quad B_o=B-B_\chi,
\]
\[
 M_\chi=\int\chi\left(2|W^+|^2+\frac23-\frac{\rho^2}{8}\right)
                         \ge\frac{13}{24}\int\chi\ge0.
 \tag{4.3}
\]

The signed flux \(q_\chi\) is a different object from the relative
determinant square \(q_A^{\rm rel}\). In particular, the low-amplitude
region has not been identified as a marked whole surgery core.

### 4.1. Exact spatial balances

The transgression identity \(dT_u=c_2(\mathbb F)\) and the extension of
\((1-\chi)T_u\) by zero near all spinor zeros give

\[
 \ell=\int\chi c_2(\mathbb F)+q_\chi.
\]

There is no transversality or regular-level-set assumption. For the actual
positive-spinor connection the signed Chern density is

\[
 16\pi^2c_2(\mathbb F)=
 \left(|F_A^+|^2-|F_A^-|^2-2|W^+|^2
             -\frac{s^2}{24}+\frac{|\operatorname{Ric}^{\circ}|^2}{2}\right)d\mu.
\]

Use \(s=-4\) and \(|F_A^+|^2=\rho^2/8\). This proves the two exact identities

\[
 \boxed{P_\chi=32\pi^2\ell+2B_\chi+2M_\chi-32\pi^2q_\chi,}
 \tag{4.4}
\]
\[
 \boxed{P-8\pi^2Ah=P_o+8\pi^2(p-A)+2J-2B_o
                              +2M_\chi-32\pi^2q_\chi.}
 \tag{4.5}
\]

For (4.5), substitute (4.2) in (4.4) and use \(Ah=k+4\ell\).
The only unfavorable terms are exterior ASD determinant energy and positive
signed transition flux. This specifies a spatial source of the earlier
signed remainder; it does not discard the Weyl payment tested by X06.

### 4.2. First-order necessary conditions

Suppose \(\mathcal E=O(h)\). With \(e=R/(8\pi^2A)\), the two classical
energy walls give

\[
 1+h\le e\le\frac{U}{1-\mathcal E}=1+O(h).
\]

Thus on any subsequence on which \(\mathcal E/h\to c\),
\(P/(Ah)\to2\pi^2c\). Moreover
\(U=1+15k/A-12\ell/A\) implies

\[
 \frac{k}{Ah}\to\frac29,\qquad
 \frac{\ell}{Ah}\to\frac7{36}.
 \tag{4.6}
\]

Dropping only the displayed nonnegative terms in (4.4) gives

\[
 \boxed{\liminf\frac{q_\chi}{Ah}
                         \ge\frac7{36}-\frac c{16}.}
 \tag{4.7}
\]

In particular, a coefficient below \(28/9\) requires positive signed flux
of first-order size. Conversely, the **additional** condition
\(\limsup q_\chi/(Ah)\le0\) forces \(c\ge28/9\), not four. The class supply
does not establish that sign condition.

For every \(c<4\), (4.5) instead gives

\[
 \boxed{\liminf\frac{B_o+16\pi^2q_\chi}{Ah}
                                      \ge\pi^2(4-c).}
 \tag{4.8}
\]

Thus proving both \(B_o=o(Ah)\) and \((q_\chi)_+=o(Ah)\) would suffice for
the coefficient-four lower bound. These are substantive missing estimates,
not consequences asserted here of near-minimality.

### 4.3. The flux demands an actual critical mixed current

Set \(T=\{1/2<\rho<1\}\), \(\zeta=\langle\Phi,\nabla_A\Phi\rangle\), and

\[
 M_{\rm mix}=\int_T|\zeta|^2|\nabla_A\Phi|^2.
\]

For this ordinary solution, the exact nonnegative remainder in
[I47, Section 4.1](20260927_full_core_cost_and_extremal_metrics.md) reads

\[
 D_2/18=F_{\rm fit}+\Gamma/2+J+H,
\]
\[
 \Gamma=\int\left(\frac{|d\rho|^2}{4}+|\operatorname{Im}\zeta|^2\right),
 \quad H=\frac23\int(1-x)^2(2+4x-x^2),\quad x=\rho/4,
\]
\[
 F_{\rm fit}=\int|W^+-W_0|^2,\quad
 W_0=\tfrac12(|\sigma(\Phi)|^2I/3-\sigma(\Phi)\otimes\sigma(\Phi)).
 \tag{4.9}
\]

In particular \(Q:=\int(4-\rho)^2\le2D_2/3\) and
\(\Gamma\le D_2/9\). On \(T\), volume is at most \(Q/9\), the model
\(W_0\) is bounded, and \(F_{\rm fit}\le D_2/18\). If \(\Omega\) denotes
trace-free positive-spinor curvature, then
\(G^2=|\Omega|^2+|F_A^+|^2\) satisfies

\[
 \int_TG^2\le C(P+D_2).
\]

The exact transgression in a unitary \((u,v)\) frame is

\[
 4\pi^2T_u=-a_{\rm conn}\wedge\mathbb F_{22}
 +\tfrac12(b\wedge\mathbb F_{12}-\bar b\wedge\mathbb F_{21})
 +a_{\rm conn}\wedge\bar b\wedge b.
\]

On \(T\), \(|d\rho|\le2|\zeta|\),
\(|a_{\rm conn}|\le2|\zeta|\), and
\(|b|\le\sqrt2|\nabla_A\Phi|\). Hence Cauchy--Schwarz, without a
Sobolev or Hessian estimate, gives

\[
 \boxed{|q_\chi|\le
 C\left\{\sqrt{(P+D_2+B)M_{\rm mix}}+M_{\rm mix}\right\}.}
 \tag{4.10}
\]

The central term is controlled using
\(\int_T|\zeta|^4\le M_{\rm mix}\). Along the above first-order sequences,

\[
 D_2=36\pi^2A\{e-1-h-2(p/A-1)\}\ge0
\]

implies \(D_2,p-A=O(Ah)\), and (4.2), (4.9) give \(B=O(Ah)\).
Thus a coefficient bounded strictly below \(28/9\) forces
\(\liminf M_{\rm mix}/(Ah)>0\). This is a necessary actual concentration,
not its exclusion.

If additionally \(D_2=o(Ah)\), then
\(\operatorname{Vol}(T),\Gamma=o(Ah)\). To control the ordinary spinor's
quadratic derivative there, test
\(4\nabla_A^*\nabla_A\Phi+(\rho-4)\Phi=0\) against
\(\theta(\rho)\Phi\), where \(\theta=1\) below 1, zero above 2, and
\(\theta'\le0\) is bounded. Integration by parts gives

\[
 4\int\theta|\nabla_A\Phi|^2
  =\int\theta(4-\rho)\rho-2\int\theta'|d\rho|^2
  \le C(Q+\Gamma)\le CD_2.
 \tag{4.11}
\]

Therefore below the stated threshold,

\[
 \operatorname{Vol}(T),\ \int_T|\nabla_A\Phi|^2=o(Ah),
 \qquad \int_T|\zeta|^2|\nabla_A\Phi|^2\ge c_*Ah.
 \tag{4.12}
\]

In particular the derivative supremum diverges, since
\(M_{\rm mix}\le\sup_T|\nabla_A\Phi|^2\,\Gamma\).
No estimate for a different weighted solution was substituted here.

### 4.4. Conditional critical patterns

If \(c=28/9\) and \(\limsup q_\chi/(Ah)\le0\), equality in the limiting
nonnegative balance (4.4) forces

\[
 P_o,B_\chi,M_\chi=o(Ah),\quad q_\chi=o(Ah),\quad
 \liminf\frac{B_o}{Ah}\ge\frac{8\pi^2}{9}.
 \tag{4.13}
\]

All leading Ricci error lies in the low-amplitude region, while the indicated
ASD determinant energy lies outside. Since \(\int\chi=o(Ah)\) but
\(P_\chi/(Ah)\to56\pi^2/9\), \(\|\operatorname{Ric}^{\circ}\|_\infty\)
diverges on that region.

If instead \(c=4\), \(B_o=o(Ah)\), and \((q_\chi)_+=o(Ah)\), then (4.5)
forces

\[
 P_o,p-A,J,M_\chi,q_\chi=o(Ah),\quad
 \frac{B_\chi}{Ah}\to\frac{8\pi^2}{9},\quad
 \frac{P_\chi}{Ah}\to8\pi^2.
 \tag{4.14}
\]

These are different conditional first-order patterns. Neither is a
classification of all minimizing sequences, and neither proves that the
coefficient-four sufficient conditions hold on the classical recovery family.

## 5. A quantitative criterion for torsion flux at a marked frontier

Return to the weighted zero-end solution. Let \(t=t_\Phi\),
\(m=|t|^2\), and use the inherited torsion cutoff
\(\chi=1-\theta(m)^2\), with \(\theta=0\) for
\(m\le m_\beta/16\) and \(\theta=1\) for \(m\ge m_\beta/8\).
Here \(m_\beta\) has positive upper and lower bounds for \(\beta\ge4\).
Define \(G=\theta^2T_t\), extended by zero through torsion zeros. This
\(\chi\) is the torsion cutoff, not the ordinary-spinor cutoff of Section 4.

With

\[
 k_A=9(|F_A^+|^2-|F_A^-|^2)+s^2/24-|\operatorname{Ric}^{\circ}|^2/2,
\]

the exact local version of the inherited signed identity is, for every
smooth domain \(D\),

\[
 2\int_D\theta^2|W^-|^2+\int_D\theta^2 k_A
   =16\pi^2\left(\int_Dd\chi\wedge T_t+
                                      \int_{\partial D}G\right).
 \tag{5.1}
\]

This follows by integrating
\(dG=-d\chi\wedge T_t+\theta^2c_2(E_-)\). Boundary terms cancel for an
actual partition, but need not disappear in a limiting decomposition.

### 5.1. A scale-free trace bound

Consider a controlled collar of radius \(r_e\) and order \(n_e\) as in
Section 1.2. Put

\[
 E_e=\int_{\mathcal C_e}|F_{E_-}|^2,\qquad
 J_e=\int_{\mathcal C_e\cap\{m>m_\beta/16\}}|\nabla u|^4,
 \qquad u=t/|t|.
\]

Here the derivative is that of the actual unit section, including its phase,
not just its image in the projective bundle. The rank-two transgression gives

\[
 |G|\le C\theta^2(|F_{E_-}||\nabla u|+|\nabla u|^3).
\]

Use coarea to choose an interior slice, then Hölder on the collar.
Since \(\operatorname{Vol}(\mathcal C_e)\le Cr_e^4/n_e\),

\[
 \boxed{\left|\int_{Y_e}G\right|
 \le C n_e^{-1/4}
                  (E_e^{1/2}J_e^{1/4}+J_e^{3/4}).}
 \tag{5.2}
\]

The physical radius cancels. By selecting from the good sets of the two
coarea estimates, the same slice can satisfy (1.8) and (5.2).
Let \(H=\sum_e n_e^{-1}\). Hölder in the interface index gives

\[
 \boxed{\frac1V\sum_e\left|\int_{Y_e}G\right|
 \le C\left(\frac HV\right)^{1/4}
 \left[
   \left(\frac{\sum E_e}V\right)^{1/2}
   \left(\frac{\sum J_e}V\right)^{1/4}
       +\left(\frac{\sum J_e}V\right)^{3/4}
 \right].}
 \tag{5.3}
\]

For marked frontiers of Section 2, \(H/V\le N/V\to0\). If their normalized
quartic torsion-direction energy stays bounded and their normalized curvature
energy stays bounded, no normalized torsion boundary flux is lost at the
selected cuts.

Under \(p\ge A>0\) and \(\chi(M)/A\le B\), the latter curvature bound follows from the
original actual budgets, rather than an additional \(C^2\) collar condition.
In the project's curvature norms,

\[
 |F_{E_-}|^2=|W^-|^2+s^2/48
                +|\operatorname{Ric}^{\circ}|^2/4+(9/2)|F_A|^2.
\]

Gauss--Bonnet gives
\(\int|W^-|^2\le8\pi^2\chi+P/2\), and Section 2.3 controls \(\chi/V\).
For bounded-overlap collars, therefore, \(\sum E_e/V\le C(B)\Lambda\).

### 5.2. Surviving flux forces a faster critical concentration

Write \(d=H/V\), \(j_4=\sum J_e/V\), and suppose the left side of (5.3)
is at least a fixed \(b>0\), while \(\sum E_e/V\le E_0\). At least one
of its two summands must be at least \(b/2\). Hence

\[
 j_4\ge c\min\left\{\frac{b^4}{dE_0^2},
                               b^{4/3}d^{-1/3}\right\}.
 \tag{5.4}
\]

For \(d\to0\) and fixed \(b,E_0\), this implies

\[
                 \boxed{j_4\ge c(b,E_0)d^{-1/3}.}
 \tag{5.5}
\]

In the uniformly small-core-volume version (2.4), \(d\le C\epsilon_*\),
so surviving macroscopic flux forces
\(j_4\ge c\epsilon_*^{-1/3}\). This is stronger than a merely positive
quartic concentration requirement.

The quantifier matters: the macroscopic flux must survive the
**coarea-selected cuts**, or every admissible cut, not just a preselected
hypersurface. Moving a cut can transfer nonclosed \(G\) into the bulk and
transition terms of (5.1). The global signed identity does not alone force
all of its flux through a chosen marked frontier.

The lower bound for \(|t|\) on this region implies
\(|\nabla u|\le C|\nabla t|\). Current actual budgets therefore bound the
normalized quadratic direction energy, but not the quartic quantity in (5.5).
Pure radial amplitude change cannot by itself supply this boundary flux.

For completeness put \(L_2=V^{-1}\sum\int|\nabla u|^2\) over these collar
regions. All sets below are restricted to
\(\bigcup_e(\mathcal C_e\cap\{m>m_\beta/16\})\); multiplicity is
\(\sum_e\mathbf1_{\mathcal C_e\cap\{m>m_\beta/16\}}\).
With \(L_2\le C\Lambda\) and \(j_4\to\infty\), the set
\(Z=\{|\nabla u|^2\ge j_4/(2L_2)\}\), counted with this multiplicity,
satisfies

\[
 \frac{\operatorname{Vol}_{\rm mult}(Z)}V
        \le\frac{2L_2^2}{j_4},\qquad
 \frac1V\sum_e\int_{\mathcal C_e\cap Z}|\nabla u|^4\ge j_4/2.
 \tag{5.6}
\]

Thus the forced divergent quartic mass lies on vanishing relative volume.
Equations (5.5)--(5.6) in particular force
\(\sup|\nabla u|\ge c d^{-1/6}\), and hence a corresponding bound for
the physical \(|\nabla t|\) on that region.

### 5.3. An explicit routing condition, and the remaining alternative

Here is one sufficient condition that ensures the required macroscopic flux
survives the selected cuts. Suppose disjoint marked whole cores have total
volume \(o(V)\), all the torsion low-amplitude region \(\{\chi\ne0\}\)
lies strictly inside them, and \(\chi=0\) throughout every admissible outer
collar and the exterior. This is an additional actual-field condition.

For any coarea-selected cuts, apply (5.1) to their exterior \(D\). Its
transition term is zero. The inherited fits give
\(V^{-1}\int_M k_A=20/3+O(\epsilon_*)\) and
\(V^{-1}\int_{M\setminus D}|k_A|=o(1)\). Since the \(W^-\) term is
nonnegative, the sum of **outward core** fluxes is negative and obeys

\[
 -\frac1V\sum_e\int_{Y_e}G
                         \ge\frac5{12\pi^2}-o(1).
 \tag{5.7}
\]

If also \(p\ge A>0\) and \(\chi(M)/A\le B\), the curvature input to (5.5) is automatic.
The resulting alternative is precise: such a routing decomposition of an
actual endpoint sequence must have

\[
 \frac1V\sum_e\int_{\mathcal C_e\cap\{m>m_\beta/16\}}|\nabla u|^4
                 \ge c(B,K)(H/V)^{-1/3}\longrightarrow\infty.
 \tag{5.8}
\]

In particular a decomposition satisfying the strictly weaker-than-bounded
condition \(j_4=o((H/V)^{-1/3})\) is impossible. This connects a genuine
global field-routing premise to a quantified failure, rather than assuming
an arbitrary boundary has macroscopic flux.

Weak input has not yet supplied this decomposition or ruled out (5.8).
Trivial spherical interfaces are a further distinct possibility: (5.2)
holds for them with \(n=1\), but the determinant atom does not bound their
number. The actual local example in Section 3.1 explains why they cannot
be silently omitted from a proposed decomposition. These alternatives leave
the unrestricted endpoint theorem open.

### 5.4. Why level cuts alone do not cancel the signed trace

The phase part of the same transgression identifies a possible false
shortcut. On \(t\ne0\), put \(j_t=\operatorname{Im}\langle t,\nabla t\rangle\),
\(m=|t|^2\), and \(f_A=-iF_A\). In a unit \(t\)-frame the diagonal
connection is \(i j_t/m\), and the determinant of \(E_-\) has curvature
\(3i f_A\). The simplified rank-two formula gives exactly

\[
 4\pi^2T_u=-m^{-2}j_t\wedge dj_t+3m^{-1}j_t\wedge f_A
          +\tfrac12(b\wedge\mathbb F_{12}-\bar b\wedge\mathbb F_{21}).
 \tag{5.9}
\]

The explicit radial derivative cancels from the first term because
\(j_t\wedge dm\wedge j_t=0\); the phase helicity does not cancel.
Thus taking a mass-level boundary, where tangential \(dm=0\), does not
force the trace to be small. The inherited hyperbolic local actual core
already has outward \(\int T_u=-1+O(\varepsilon^4)\) on its nonzero outer
section, while its bulk characteristic integral tends to zero. No
nonpositive-flux theorem or improved signed trace bound follows from
level selection alone.

## 6. Consequences for the continuing research

There are now two distinct actual connections, not one interchangeable
charge:

- The determinant's full relative charge is tight on existing marked small
  whole cores, including harmonic replacement and arbitrary finite depth.
- Torsion indices can grow relative to that charge, and an actual local
  trivial-boundary core can carry torsion index with zero determinant charge.
  Any global argument must retain the actual section framing or directly
  control the resulting signed flux.

For the zero-end target, the next sufficient step is either direct actual
control of the signed transition in (5.1), or a decomposition that proves
both a genuine flux-routing statement and enough control to contradict
(5.5). Proving the first does not require completing all possible core
classifications. For balanced first-order sharpness, (4.5) instead identifies
the two actual quantities whose leading contribution must be decided.

The present arguments do not give an unrestricted endpoint gap, a
Gamma-limit, the balanced optimal coefficient, diameter-free realization,
or the Einstein classification of the fixed Dehn-twist manifold. Those
remain separate open statements. The written proofs above provide specific
new conditional connections and identify exactly which proposed stronger
charge comparisons are false.


END COMPLETE SOURCE


---

## Source 2: 20260927_constant_weight_and_global_fit.md

Original path: `continuation/20260927_constant_weight_and_global_fit.md`

SHA-256: `40fd06e6376600fe84a1e51c9574b26497bb90623c3a0702161ae98ad24c22f6`

BEGIN COMPLETE SOURCE

# Constant-weight calibration and the cost of extending actual cores

27 September 2026. Continuation of `e58b867` under the
[unified research directive](../guidance/source/20260927_unified_research_directive.zh.md).
The actual supply, curvature norms and orientations are those of
[I07](../mathematics/current/line1_functional_pencil.md),
[I40](20260927_mixed_current_and_signed_cores.md), and
[I41](20260927_conformal_separation_and_zero_end.md).

The first result replaces the variable-weight endpoint field by **any**
constant-weight actual solution after a controlled conformal reduction.
An exact nonnegative identity controls its amplitude, harmonic-curvature
remainder and Maxwell residual, uniformly in the parameter. Keeping its
two error scales separate improves the all-metric compactified gap from
cubic to quadratic at the zero-Weyl end, and strengthens the upper energy
wall on the same actual topological inputs. The subsequent
calculations test the actual high-index cores against the missing global
matching, and retain the curvature-action cancellation in the balanced
first-order problem. Neither O10 nor the balanced optimal coefficient is
settled here.

## 1. The weak endpoint can be studied at constant scalar curvature

Let the fixed Spin-c structure be solvable for every metric in the conformal
class of a closed oriented four-metric \(g\), with
\(p=(a_g^+)^2>0\). As in I07, put

\[
 S_2=\int s^2,\quad P=\int|\operatorname{Ric}^{\circ}|^2,
 \quad w=\sqrt6|W^+|,\quad
 D_\beta=(1+\beta^{-1})S_2+(\beta+1)\int w^2-72\pi^2p,
\]
\[
 r=V^{-1}\int|\operatorname{Ric}+g|^2,\qquad
 \kappa=r+D_\beta/V,\qquad \beta\ge2.
 \tag{1.1}
\]

The conformal class has negative Yamabe constant: a nonnegative constant
scalar representative would contradict the positive actual monopole
projection by the spinor Weitzenbock formula. Let \(\widehat g\) be its
scalar-minus-four representative. Hodge star on two-forms, \(p\), and the
integrated Weyl energies are conformally invariant. The exact identities
proved in I41 Section 1 give

\[
 \delta=S_2-\widehat S_2\ge0,\qquad
 \widehat P=P-\delta/12,\qquad
 \widehat D_\beta=D_\beta-(1+\beta^{-1})\delta\ge0.
 \tag{1.2}
\]

Thus \(0\le\delta\le D_\beta\). If \(e=s+4\), then
\(\int e^2\le4rV\) and
\(S_2=16V-8\int e+\int e^2\). Since
\(\widehat S_2=16\widehat V\),

\[
 1-\sqrt r-\kappa/16
 \le\frac{\widehat V}{V}
 \le1+\sqrt r+r/4.
 \tag{1.3}
\]

In particular, when the left denominator is positive,

\[
 \boxed{\widehat\kappa
 =\frac{\widehat P+\widehat D_\beta}{\widehat V}
 \le\frac{\kappa}{1-\sqrt\kappa-\kappa/16}.}
 \tag{1.4}
\]

An actual sequence with \(\beta\to\infty\), \(\kappa\to0\) therefore
exists if and only if such a sequence exists with \(s=-4\). The same
class, its square condition, and \(\chi/A\) are retained;
\(\widehat V/V\to1\). There is no pointwise Ricci or conformal-factor
regularity claim. This is an endpoint consequence of the inherited exact
conformal identities, not a new Yamabe existence theorem.

We will also need a comparison independent of \(D_\beta\). Write
\(g=u^2\widehat g\), with \(\Delta=d^*d\) on \(\widehat g\).
The scalar transformation gives
\(e u^2=6u^{-1}\Delta u+4(u^2-1)\). Expand its square and integrate.
The cross term is \(48\int(u-u^{-1})\Delta u
=48\int(1+u^{-2})|du|^2\). Subtract the exact formula for \(\delta\)
in I41 Section 1 to obtain

\[
 \boxed{\int_g(s_g+4)^2=\delta
 +16\int_{\widehat g}(u^2-1)^2+48\int_{\widehat g}|du|^2.}
 \tag{1.5}
\]

In particular \(\delta\le4rV\). Moreover,

\[
16\widehat V=16V-8\int_g e+\left(\int_g e^2-\delta\right)
\ge16V(1-\sqrt r),\qquad e=s_g+4.
\tag{1.6}
\]

Thus \(\widehat V/V\ge1-\sqrt r\), whether or not
\(D_\beta/V\) is small. This is an energy comparison, not a bound
on the Hessian of the conformal factor in a uniformly controlled chart.

## 2. An exact constant-weight calibration for every finite parameter

Work now with \(s=-4\). Take **any** actual solution

\[
 D_A\Phi=0,\qquad F_A^+=2i\sigma(\Phi).
 \tag{2.1}
\]

It exists by scaling an ordinary unperturbed solution: if its spinor is
\(\Psi\), take \(\Phi=\Psi/\sqrt2\). No continuity, uniqueness, or
comparison with the earlier variable-weight solutions is used. The maximum
principle gives \(0\le\rho=|\Phi|^2\le2\). Set

\[
 \psi=2\sqrt2\sigma(\Phi),\qquad
 \zeta=\langle\Phi,\nabla_A\Phi\rangle,
 \quad J=\|F_A^+-(F_A^+)_H\|_2^2\ge0,
\]
\[
 E_\lambda=\langle W^+\psi,\psi\rangle+w\rho^2/3\ge0,
\]
\[
 D_0=2\int|d\rho|^2+
 \int(4\rho|\nabla_A\Phi|^2-|\nabla\psi|^2)
       +2\int|d\psi|^2+2\int E_\lambda\ge0.
 \tag{2.2}
\]

For \(\beta\ge2\), define

\[
 c=\frac{4(\beta+1)}{3\beta}\in[4/3,2],\qquad
 z=w-4/\beta,\qquad
 C_\beta(\rho)=\rho+c/2-\frac{(\rho+c)^2}{2c(\beta+1)}.
 \tag{2.3}
\]

**Theorem (same-solution constant-weight identity).**

\[
\boxed{\begin{aligned}
 \frac{c}{18}D_\beta={}&\frac12D_0+cJ
       +\int(\rho-c)^2 C_\beta(\rho)\\
 &+\frac{c(\beta+1)}{18}
       \int\left[z-\frac{3(\rho^2-c^2)}{c(\beta+1)}\right]^2.
\end{aligned}}
 \tag{2.4}
\]

Every term on the right is nonnegative. In particular,

\[
 \boxed{D_0\le\frac29D_\beta,\quad
 J\le\frac1{18}D_\beta,\quad
 \int(\rho-c)^2\le\frac16D_\beta.}
 \tag{2.5}
\]

**Proof.** The actual spinor/form identities in I07, with weight exactly
two, read

\[
 D_0=\frac23\int(4+w)\rho^2-2\int\rho^3.
 \tag{2.6}
\]

Since \(|F_A^+|^2=\rho^2/2\), Hodge projection gives

\[
 9\int\rho^2
 =16(1+\beta^{-1})V+(\beta+1)\int w^2-D_\beta+18J.
 \tag{2.7}
\]

Insert (2.7) into (2.6), use (2.3), and expand the cubic around \(c\).
Before completing the last square, the result is

\[
 \frac12D_0+cJ+\int(\rho-c)^2(\rho+c/2)
  +\frac{c(\beta+1)}{18}\int z^2
 =\frac c{18}D_\beta+\frac13\int z(\rho-c)(\rho+c).
 \tag{2.8}
\]

Completing the \(z\) square gives (2.4). Further,
\(C_\beta(0)=2/3\), and

\[
 C_\beta'(\rho)
 =\frac{\beta(4\beta+4-3\rho)}{4(\beta+1)^2}>0
 \quad (0\le\rho\le2).
\]

Thus \(C_\beta\ge2/3\). Dropping terms gives (2.5), using \(c\le2\).
This proof never changes the actual solution. QED.

There is an equivalent full Weyl-square identity. Define the globally
smooth polynomial model

\[
 \alpha=\frac{9\beta}{8(\beta+1)^2},\qquad
 W_0=\alpha(\rho^2 I/3-\psi\otimes\psi).
\]

Its two repeated eigenvalues are \(\alpha\rho^2/3\). Direct expansion
in the three-dimensional self-dual bundle gives

\[
 |W^+-W_0|^2=(w-2\alpha\rho^2)^2/6+2\alpha E_\lambda.
\]

The square in (2.4) is exactly \((w-2\alpha\rho^2)^2\).
Using (2.9) below cancels the \(E_\lambda\) term and yields

\[
 \boxed{\frac{D_\beta}{18}=J+\frac4c\int|\zeta|^2
 +\frac{\beta+1}{3}\int|W^+-W_0|^2
 +\frac1c\int C_\beta(\rho)(\rho-c)^2.}
 \tag{2.9a}
\]

At \(\beta=2\), rescaling back to the ordinary spinor gives precisely
the four-term identity in I47 Section 4.1. The extension here is the
same-solution identity for the whole finite parameter range, not a new
claim about the already established beta-two case. It requires only
the actual solution (2.1) on the scalar-minus-four metric; conformal
solvability was used to reach and supply that representative in Section 1.

### 2.1. A first-order Maxwell estimate without a spectral gap

The exact Hopf/Dirac identities used in I47 Section 4.1 are

\[
 d\rho=2\operatorname{Re}\zeta,\quad
 |\nabla\psi|^2=4\rho|\nabla_A\Phi|^2
                       -4|\operatorname{Im}\zeta|^2,
 \quad |d\psi|^2=2|\operatorname{Im}\zeta|^2.
\]

Consequently

\[
 D_0=8\int|\zeta|^2+2\int E_\lambda.
 \tag{2.9}
\]

The determinant Bianchi identity is \(dF_A=0\), and
\(F_A^+=i\psi/\sqrt2\). In the project's Clifford convention,
\(\delta F_A=-2i\operatorname{Im}\zeta\). Its norm, independently of
the sign convention, therefore obeys

\[
 \boxed{\|\delta F_A\|_2^2
 =4\|\operatorname{Im}\zeta\|_2^2
 \le D_0/2\le D_\beta/9.}
 \tag{2.10}
\]

Let \(H_A\) be the harmonic representative of the same imaginary curvature
class. The exact form \(F_A-H_A\) has zero square integral, so its two
chiral squared norms are equal. Hence

\[
 \boxed{\|F_A-H_A\|_2^2=2J\le D_\beta/9,\qquad
 d(F_A-H_A)=0,\qquad
 \|\delta(F_A-H_A)\|_2^2\le D_\beta/9.}
 \tag{2.11}
\]

In fact the sum is bounded by the same constant:
\(\|F_A-H_A\|_2^2+\|\delta(F_A-H_A)\|_2^2\le D_\beta/9\).
Indeed (2.4) gives
\(\|\delta F_A\|_2^2+(c/2)\|F_A-H_A\|_2^2\le cD_\beta/18\),
and \(c/2\le1\).

This is a Hodge graph-norm bound. It is not a rough covariant
\(W^{1,2}\) bound on two-forms: the latter introduces the uncontrolled
opposite Weyl curvature in the Weitzenbock formula. Nor does (2.11)
bound \(d\delta F_A\) in \(L^2\). Spectrally, coefficients of size
\(\lambda^{-1}\) at eigenvalue \(\lambda\to\infty\) have vanishing
graph norm but a nonvanishing Laplacian. Such a spectral illustration is
not an actual counterexample to the coupled equations.

By (2.5), \(\rho\to4/3\) in normalized \(L^2\) at squared error
\(O(D_\beta/V+\beta^{-2})\). With
\(\omega=(3\sqrt2/4)\psi\),

\[
 \|\omega\|_\infty\le3\sqrt2/2,\qquad
 \fint\left[(|\omega|^2-2)^2+|d\omega|^2\right]
       \le C(D_\beta/V+\beta^{-2}).
 \tag{2.12}
\]

Thus the unrestricted actual endpoint can be attacked using a scalar-minus-four
metric and a constant-weight solution with small Maxwell residual. All
original supplier quantifiers remain in force; only the analytic field
chosen for the proof has changed. No bound on \(\nabla w\) or derivative
of an auxiliary weight is needed.

### 2.2. Continuing the Maxwell equation to the critical source

The current has \(\operatorname{Re}\zeta=d\rho/2\). Hence, in the
same convention as (2.10),
\(d\zeta=-d\delta F_A/2\). Since \(dF_A=0\), the actual torsion
curvature relation of I40 Section 3 becomes the global polynomial identity

\[
 \boxed{\rho^2\Delta_H F_A^-+\rho^3F_A^-
                  =-2q_-(t)+\mathcal R,}
 \tag{2.13}
\]
\[
 |\mathcal R|\le C\left(\rho^3|\operatorname{Ric}^{\circ}|
                 +\rho^{3/2}|\zeta||\nabla_A\Phi|\right).
\]

Hodge Laplacian commutes with chirality. On \(\{\rho>0\}\) this is
\((\Delta_H+\rho)F_A^-=-2q_-(t)/\rho^2+\mathcal R/\rho^2\).
The source has no singular norm bound there: the exact pointwise
\(|t|^2\le2\rho^2|\nabla_A\Phi|^2\) and
\(|\zeta|\le\sqrt\rho|\nabla_A\Phi|\) bound its magnitude by
\(C(\rho|\operatorname{Ric}^{\circ}|+|\nabla_A\Phi|^2)\).
But its squared norm involves the critical fourth-power gradient energy.
The available budget bounds that quantity, not its concentration by a
small multiple of \(V\). Division by \(\rho\) across the zero set is
not needed or asserted in (2.13).

There is also a precise remaining term in a covariant-regularity attempt.
For the real ASD form \(a_-=-iF_A^-\),

\[
 \|\nabla a_-\|_2^2=2\|da_-\|_2^2+
       \frac43\|a_-\|_2^2+2\int\langle W^-a_-,a_-\rangle.
 \tag{2.14}
\]

Even if \(a_-=K+E\), with a bounded fitted model \(K\),
\(\|E\|_2^2=o(V)\), and \(\|W^-\|_2^2\le C(B)V\), only the
\(K,K\) and \(K,E\) terms are controlled by these norms. The remaining
\(\int\langle W^-E,E\rangle\) requires information not supplied by
two separate \(L^2\) bounds. Thus (2.13) is a concrete new way to use
the full equations, not a regularity or zero-end-gap conclusion.

The natural signed pairing can be taken further. Along a hypothetical
zero-end sequence assume \(a^2\ge T_+\), put
\(\eta=r+D_\beta/V+\beta^{-2}\le1\), and use normalized norms below.
Set \(\rho_*=4/3\), \(U_*=-4/3\), \(m_*=128/81\),
\(\Pi=\nabla_A\Phi\), \(\tau=t_\Phi\), \(m=|\tau|^2\), and
\(S=m_*+2\rho^2|\Pi|^2\). The constant-weight identities give

\[
\Delta\rho=-2|\Pi|^2-(-4+2\rho)\rho/2,\qquad
0\le\nu:=2\rho^2|\Pi|^2-m\le4\rho|\zeta|^2.
\]

The estimates above and the inherited Hessian estimate imply
\(\|\rho-\rho_*\|_2+\|\zeta\|_2+\|d\rho\|_2
+\|\operatorname{Ric}^{\circ}\|_2\le C\sqrt\eta\), with
\(\Pi,\tau\) bounded in normalized \(L^4\) and
\(\nabla_A\Pi,\nabla\tau\) bounded in normalized \(L^2\).
Thus \(\fint S=2m_*+O(\sqrt\eta)\), \(\fint S^2\le C\),
and \(\fint\nu=O(\eta)\). The scalar test \(2\rho^2/S\) has derivative

\[
d(2\rho^2/S)=\frac{4m_*\rho}{S^2}d\rho
 -\frac{8\rho^4}{S^2}\operatorname{Re}\langle\Pi,\nabla_A\Pi\rangle.
\]

It is bounded in normalized \(L^2\), so this test gives
\(\fint S^{-1}=(2m_*)^{-1}+O(\sqrt\eta)\). The same nonnegative
reciprocal defect as in [I40, Section 8](20260927_mixed_current_and_signed_cores.md)
then yields \(\fint m^2/S=m_*/2+O(\sqrt\eta)\) and
\(\fint(m/S)^2=1/4+O(\sqrt\eta)\).

Write real ASD forms \(f=-iF_A^-\), \(Q=-iq_-(\tau)\),
\(R=-i\mathcal R\), and \(B=\rho^3Q/S\). Pairing the actual curvature
equation with \(Q/S\), whose weighted derivative test is bounded by
I40 (8.10), gives
\(\fint\langle f,B\rangle=-m_*/8+O(\sqrt\eta)\) and
\(\fint|B|^2=\rho_*^6/32+O(\sqrt\eta)\).
Chern--Weil supplies

\[
 \fint|f|^2+\frac{4\pi^2(a^2-T_+)}V
 =\fint\rho^2/2-2\fint|W^+|^2-2/3+r/2
 =2/9+O(\sqrt\eta).
\]

Completing the square, exactly as in I41 Section 6, proves

\[
 K=-\frac{4m_*}{\rho_*^6}B,\qquad \|K\|_\infty\le C,\qquad
 \|f-K\|_2^2+\frac{4\pi^2(a^2-T_+)}V\le C\sqrt\eta.
 \tag{2.14a}
\]

All denominators are bounded below by \(m_*\); this transfers the
bounded ASD fit to this same constant-weight solution without identifying
it with an earlier weighted solution.

Let \(\gamma=\operatorname{Im}\zeta\). Since
\(\delta f=-\gamma\), \(df=*\gamma\), integration by parts in
(2.13) gives the exact identity

\[
\begin{aligned}
 \int\rho^3|f|^2+2\int\langle Q,f\rangle+2\int\rho^2|\gamma|^2
 ={}&\int\langle R,f\rangle\\
 &-4\int\rho\langle\gamma,\iota_{\nabla\rho}f\rangle.
\end{aligned}
 \tag{2.14b}
\]

The right side is \(O(\eta^{1/4}V)\). Indeed R is bounded in normalized
\(L^2\) and has \(L^1\) norm \(O(\sqrt\eta)\); the ASD form
\(\rho(d\rho\wedge\gamma)^-\) is similarly \(L^2\)-bounded and
\(L^1\)-small. Pair their bounded-model parts with K and their remaining
parts with \(f-K\) using (2.14a). Testing instead against the harmonic
\(h=-i(H_A)^-\) gives the same formula with the test factor f replaced
everywhere by h, without the nonnegative \(\gamma^2\) term. Its error
is also small by (2.11).

This closes the error in these signed tests, but their principal terms
balance: \(\fint\rho^3|f|^2\to128/243\), whereas
\(2\fint\langle Q,f\rangle\to-128/243\). It is not a contradiction.
Testing instead with \(\Delta_H f\) leaves
\(4\int\langle\gamma,\delta Q\rangle\) and
\(\int\langle R,\Delta_H f\rangle\).
The estimate \(|\delta Q|\le C|\tau||\nabla\tau|\) gives only a
critical bounded contribution, not a vanishing one. This identifies the
unpaid derivative coupling rather than assigning a false positive sign
to (2.14b).

### 2.3. An anisotropic all-metric gap

The improved Weyl-fit coefficient in (2.9a) changes the parameter estimate;
it should not be discarded by replacing every error with \(r+D_\beta/V\).

**Theorem.** Under the actual conformal supplier of Section 1, with
\(b_a=(-a^2)_+/V\), there is a universal \(c_0>0\) such that

\[
 \boxed{(1+b_a)\left(r+\frac{D_\beta}{\beta V}\right)
       \ge c_0\frac{(\beta-2)^2}{\beta^4},\qquad \beta\ge2.}
 \tag{2.15}
\]

If \(a^2\ge T_+=2\chi+3\tau\), the factor \(1+b_a\) can be
removed. No pointwise curvature, Euler-density, diameter, noncollapse,
Sobolev, or stationarity bound is assumed.

**Proof on a scalar-minus-four metric.** Put
\(t=1/\beta\), \(d=D_\beta/V\), \(\varepsilon=r+td\), and
\(\omega=\sqrt2\psi/c\), \(v=|\omega|^2\). Then

\[
 W_0=t(vI/3-\omega\otimes\omega),\quad
 \fint|W^+-W_0|^2\le Ctd,
\]
\[
 \|\omega\|_\infty\le C,\qquad
 \fint\bigl((v-2)^2+|dv|^2+|d\omega|^2\bigr)\le Cd.
 \tag{2.16}
\]

Here the endomorphism model has coefficient \(t\), not \(t/2\).
All bounds follow from the same solution in (2.9a). Its coarse Hessian
budget is \(C(1+r+d+b_a)V\): the positive-spinor curvature uses only
\(W^+\), scalar curvature, Ricci and the determinant curvature;
\(\int|F_A^-|^2\le2V+4\pi^2(-a^2)_+\), while the scalar equation
bounds \(\int|\nabla_A\Phi|^2\le CV\). More precisely,
\(\nabla_A^*\nabla_A\Phi=(1-\rho/2)\Phi\), and
\(\int|\nabla_A^*\nabla_A\Phi|^2\le8V/27\).
Apply the bounded-section Hessian identity and interpolation exactly as
in I07 Section 5; no derivative estimate for \(F_A\) is needed.
No opposite Weyl or derivative-of-weight term enters this estimate.

Let \(J_t=\operatorname{div}W(W_0)\), where \(W(\cdot)\) is the
usual passage from the self-dual endomorphism to its curvature tensor,
and \(X=\fint|J_t|^2\). The derivative of this polynomial has its
explicit factor \(t\), so
\(\fint|\nabla J_t|^2\le Ct^2(1+r+d+b_a)\).
The weak Bianchi self-test therefore gives

\[
 X\le Ct\sqrt{(r+td)(1+r+d+b_a)}.
 \tag{2.17}
\]

For completeness, the exact polynomial/Hodge contraction from
[round 21, Section 6, equation (17)](../mathematics/current/round21_analytic.md)
on this form is

\[
\begin{split}
 X=t^2\fint\bigl[&\tfrac43v^2-\tfrac43t v^3
 +2v\langle(W^+-W_0)\omega,\omega\rangle
 +4v|d\omega|^2-\tfrac56|dv|^2\\
 &+4\langle\iota_{\nabla v}\omega,*d\omega\rangle\bigr].
\end{split}
 \tag{2.18}
\]

Its constant-amplitude part is \((16/3)t^2(1-2t)\).
The amplitude, Weyl, and derivative errors in (2.18) are bounded,
respectively, by \(Ct^2\sqrt d\), \(Ct^2\sqrt{td}\), and
\(Ct^2d\). Thus

\[
 t^2(1-2t)\le CX+Ct^2(\sqrt d+d+\sqrt{td}).
 \tag{2.19}
\]

If \(r,d\le1\), divide by \(t>0\), insert (2.17), and use
\(t\sqrt d\le\sqrt{td}\), \(td\le\sqrt{td}\), and
\(t\sqrt{td}\le\sqrt{td}\). This proves
\(t(1-2t)\le C\sqrt{(1+b_a)(r+td)}\).
If \(r>1\) or \(d>1\), its squared conclusion follows directly from
\(r+td\ge\min(1,t)\). This proves (2.15) on the representative.

**Transfer to every input metric.** For \(r\le1/16\), (1.5) implies
\(\widehat V/V\ge1-\sqrt r\ge3/4\), and

\[
 \widehat r+t\widehat d
 =\frac{P+tD_\beta-(1/12+t+t^2)\delta}{\widehat V}
 \le2(r+td),\qquad
 1+\widehat b_a\le2(1+b_a).
\]

Apply the just-proved estimate to \(\widehat g\). For \(r>1/16\)
the desired bound is immediate after reducing \(c_0\). Finally,
\(a^2\ge T_+\) and Chern--Weil imply
\(b_a\le r/(8\pi^2)\); the small/large \(r\) split removes the
factor. QED.

This proves a stronger estimate than the inherited compactified transfer,
although its right side still tends to zero. For an exact normalized
negative Einstein metric it gives
\(D_\beta/V\ge c_0(\beta-2)^2/\beta^3\) after square-cost removal.
It does not give a positive lower bound independent of \(\beta\).

### 2.4. The upper energy wall now has a quadratic endpoint margin

Use the compactified functional \(P_t=tD_{1/t}\), extended at zero by
\(P_0=6\int|W^+|^2\). Equation (2.15) says

\[
 \boxed{(1+b_a)(r+P_t/V)\ge c_0t^2(1-2t)^2,
                    \qquad 0\le t\le1/2.}
 \tag{2.20}
\]

The prior exponent was three. This improvement is for integral Ricci
error, not only the bounded-pointwise-Ricci setting of I45.

Suppose, as in the inherited upper-wall application, that every metric
admits the specified actual selection with
\(p\ge A>0\), \(a^2\ge T_+\), and
\(T_+=A(1-h)\), \(1/4<h<1/3\). Define

\[
 e=\frac{\int|\operatorname{Ric}|^2}{8\pi^2A},\quad
 G(h)=\frac{(4+\sqrt{1-3h})^2}{9},\quad
 t_* =\frac{1-2\sqrt{1-3h}}{8+2\sqrt{1-3h}}.
\]

Then every smooth metric satisfies

\[
 \boxed{\mathcal E(g)+(G(h)-e)_+
                    \ge c_* t_*^2(1-2t_*)^2.}
 \tag{2.21}
\]

**Proof.** Retain the exact Chern--Weil identity from
[the compactified pencil, Section 3](../mathematics/current/line1_compactified_pencil.md):

\[
 P_t=k(t)R+\ell(t)P+12\pi^2(1+t)T_+-72\pi^2tp,
\]
\[
 k(t)=(1+t)(8t-1)/2,\qquad \ell(t)=2(1+t)(1-2t),
 \quad R=\int|\operatorname{Ric}|^2.
\]

At \(t=t_*\in(0,1/8)\), the topological terms cancel at \(e=G(h)\),
so
\(P_t\le8\pi^2A|k(t)|(G(h)-e)_++\ell(t)P\).
For normalized negative target error \(r\le1\), the actual scalar
budget gives \(8\pi^2A/V\le9\), and \(P/V\le r\).
Combining with (2.20) gives (2.21) for the negative-target infimum by
constant rescaling. Large residuals are immediate.

For clarity, passing to \(\mathcal E\), the infimum over both signs,
uses the inherited independent positive-target bound. If \(I=\int s\le0\),
that infimum over positive targets is four. Otherwise it is
\(\mathcal E_+=4-I^2/(RV)\ge4/e\), using
\(\int s_-^2\ge32\pi^2A\). If \(\mathcal E_+<1/2\),
the other Chern--Weil budget gives
\(e(1-\mathcal E_+)\le3\min(T_+,T_-)/A\le3\),
so \(e\le6\), contradicting \(\mathcal E_+\ge2/3\).
Thus \(\mathcal E_+\ge1/2\), which also implies (2.21) after
reducing its constant. QED.

As \(h\downarrow1/4\),

\[
 t_*^2(1-2t_*)^2=\frac49(h-1/4)^2+O((h-1/4)^3).
\]

This is an actual strengthening of the whole-metric upper wall on its
existing supplied topological families. It is not a new manifold supply,
not a proof that the quadratic rate is optimal, and not a nondegenerate
zero-end estimate.

## 3. What high index costs on an amplitude-controlled local core

We next continue X07 rather than replace an actual core by a formal matrix.
For fixed \(d\), on the rescaled hyperbolic ball \(x=ry\), take

\[
 \rho_0=4/3,\quad b=\rho_0 2^{(d-1)/2},\quad
 t_0=b(\bar z_1^d,\bar z_2^d),\qquad
 m_0=|t_0|^2.
 \tag{3.1}
\]

The antiholomorphic primitive and curved contraction of X07 give an exact
solution (2.1), with \(t(ry)=t_0(y)+O_d(r)\) in \(C^1\), on taking
\(r\) sufficiently small after \(d\). This order of choices suffices
for every diagonal assertion below; no uniform implicit-function radius
is assumed.

Fix \(0<m_1<m_2\). Work on the level core \(\Omega_d=\{m_0<m_2\}\)
and its shell \(T_d=\{m_1<m_0<m_2\}\), instead of the round collar
whose amplitude grew rapidly with \(d\). Set

\[
 K_d=\frac{\pi^2}{d^2b^{4/d}}B(1/d,1/d),\qquad
 B_d=B(2-1/d,1/d).
\]

For \(k\ge0\), elementary integration gives

\[
 \int_{\Omega_d}m_0^k
 =r^4K_d\frac{m_2^{k+2/d}}{k+2/d},\qquad
 K_d\sim\frac{\pi^2}{2d}.
 \tag{3.2}
\]

In particular, volume is asymptotic to \(\pi^2r^4/4\), whereas positive
moments of torsion mass are \(\Theta(r^4/d)\). On the shell, writing
\(\Delta m^q=m_2^q-m_1^q\),

\[
 \int_{T_d}|\nabla t_0|^2
 =4\pi^2r^2b^{-2/d}\frac{d^2}{d+1}\Delta m^{1+1/d},
 \tag{3.3}
\]
\[
 \int_{T_d}|\nabla t_0|^4
 =4\pi^2d^2(B_d+1)\Delta m^2,
 \tag{3.4}
\]
\[
 \int_{T_d}|\langle t_0,\nabla t_0\rangle|^2|\nabla t_0|^2
 =\frac{4\pi^2d^2}{3}
       [(2-1/d)B_d+1]\Delta m^3.
 \tag{3.5}
\]

**Verification.** Put \(u=b^2|z_1|^{2d}\), \(v=b^2|z_2|^{2d}\).
Then
\(d\mu=\pi^2r^4d^{-2}b^{-4/d}(uv)^{1/d-1}du\,dv\).
The change \(u=mx,v=m(1-x)\) proves (3.2). Use
\(|\nabla_y t_0|^2=2b^2d^2(|z_1|^{2d-2}+|z_2|^{2d-2})\)
for (3.3)--(3.4), and
\(|\langle t_0,\nabla_y t_0\rangle|^2
=2b^4d^2(|z_1|^{4d-2}+|z_2|^{4d-2})\) for (3.5).
The beta recurrence reduces the latter angular factor to
\((2-1/d)B_d+1\). Also
\(B_d=d-1+O(d^{-1})\), by the reflection formula for Gamma.

Thus quadratic derivative energy is \(\Theta(r^2d)\), while the two
critical shell energies are \(\Theta(d^3)\). The seed spinor satisfies
\(|\nabla\Phi_0|^2=m_0/(2\rho_0^2)\) and
\(|\nabla^2\Phi_0|^2=|\nabla t_0|^2/(2\rho_0^2)\).
For each fixed \(d\), actual perturbations converge in every required
finite norm as \(r\to0\); choose the diagonal so these relative errors
also tend to zero. The regular positive mass levels persist.

The relative torsion index remains \(d^2\); the determinant relative
square is exactly zero by Stokes on the trivial line. The former uses the
actual torsion boundary framing and is not an unframed determinant charge.
On a boundary near \(m_0=m_*=128/81\), mass is normal but outgoing
derivatives are of size \(d/r\). The whole-core mass mismatch is
\(\Theta(r^4)\), not small relative to its own volume. Both it and the
negative determinant model mismatch have vanishing integrals after a
sufficiently small insertion. A calibrated exterior is still absent.

### 3.1. What an extension must pay

Suppose an extension has a region \(U\) and compactly supported cutoff
\(\eta\), equal to one on the actual core, with

\[
 \operatorname{Vol}U\le C r^4,\qquad |d\eta|\le C/r,
 \qquad |t|\le C \text{ on }U.
 \tag{3.6}
\]

These are explicit extension hypotheses, not uniform geometric properties
of the level shell: its thickness can be of order \(r/d\), and its
extrinsic curvature of order \(d/r\). Amplitude control alone does not
give the cutoff in (3.6). Put
\(E_D=\int_U|D^-_{3A}t|^2\) and
\(E_0=\int_U(s^2+|F_A^-|^2)\).
The twisted Lichnerowicz identity applied to \(\eta t\) gives

\[
 \boxed{c r^2d\le C E_D+C r^2+C r^2\sqrt{E_0}.}
 \tag{3.7}
\]

Indeed the gradient energy on the core is bounded below by (3.3).
The Dirac product rule costs at most \(2E_D+Cr^2\). Its scalar and
determinant-curvature potential, acting on a bounded section supported
in volume \(Cr^4\), has absolute integral at most \(Cr^2\sqrt{E_0}\).
The opposite Weyl tensor does not occur in this spinorial potential.
For sufficiently large \(d\), (3.7) implies

\[
 E_D\ge c r^2d\quad\hbox{or}\quad E_0\ge c d^2.
 \tag{3.8}
\]

For the same actual solution the torsion equation bounds the first cost
by the integral of \(C(|W^+|^2+|\zeta|^2|\nabla_A\Phi|^2)\), under
the bounded-amplitude convention. Thus matching requires an additional
actual source, not merely a choice of boundary framing. Nevertheless,
if \(V\asymp d^2\), its required residual density is only
\(r^2d/V\asymp r^2/d\to0\). The alternative (3.8) therefore does
not exclude a weak endpoint sequence.

## 4. Splitting index changes the critical cost

The \(d^3\) cost of (3.5) is not universal for index \(d^2\). Fix
\(0<L<1/2\) and use the separated seed

\[
 t_0=b((\bar z_1/L)^d-1,(\bar z_2/L)^d-1).
 \tag{4.1}
\]

Its antiholomorphic primitive in the same spinor construction is

\[
 g=\frac{bL}{2\rho_0}\left[
 \frac{(\bar z_1/L)^{d+1}}{d+1}-\frac{\bar z_1}{L}
 -\frac{(\bar z_2/L)^{d+1}}{d+1}+\frac{\bar z_2}{L}\right].
 \tag{4.2}
\]

There are \(N=d^2\) simple zeros. For large \(b\), each fixed mass
component has inverse branches
\(\bar z_i=L\xi_i(1+w_i/b)^{1/d}\), with \(\xi_i^d=1\).
Their derivatives are similarities up to relative \(O(b^{-1})\),
uniformly in \(d\). Each physical component has scale
\(\ell=rL/(bd)\) and index one. Take \(r\) sufficiently small after
\((d,b)\) for the actual contraction and its relative errors.

Summing over these components, the linear-map integrals give

\[
 \operatorname{Vol}\{m<m_2\}
 =(1+o(1))\frac{\pi^2m_2^2}{2}N\ell^4,\qquad
 \int_{m<m_2}|\nabla t|^2
 =(1+o(1))2\pi^2m_2^2N\ell^2,
 \tag{4.3}
\]
\[
 \int_{m_1<m<m_2}|\nabla t|^4
 =(1+o(1))8\pi^2N\Delta m^2,
 \tag{4.4}
\]
\[
 \int_{m_1<m<m_2}|\langle t,\nabla t\rangle|^2|\nabla t|^2
 =(1+o(1))\frac{8\pi^2}{3}N\Delta m^3,
 \tag{4.5}
\]
\[
 \int_{m_1<m<m_2}|\nabla(t/|t|)|^4
 =(1+o(1))9\pi^2N\log(m_2/m_1).
 \tag{4.6}
\]

For example \(t=x/\ell\) has \(|\nabla t|^2=4/\ell^2\) and
\(|\nabla(t/|t|)|^2=3/|x|^2\); radial integration proves the constants.
The actual perturbation preserves these asymptotics, the simple indices,
and zero determinant relative charge on every component.

Here \(N\ell^2=r^2L^2/b^2\) and
\(N\ell^4=r^4L^4/(b^4d^2)\). Thus the subcritical costs vanish, while
the critical cost is only linear in total index. These are costs on the
selected components, not an estimate on all the space between them.

This also identifies a qualification in I50's frontier interpretation.
Its lower bound in terms of \((H/V)^{-1/3}\), \(H=\sum1/n_e\), forces
divergent critical density **only if \(H/V\to0\)**. A split collection
of \(N\asymp V\) trivial-character interfaces has \(n_e=1\) and
\(H/V\asymp1\), with bounded positive critical density as in (4.6).
I50's determinant atoms do not charge these interfaces. The local pattern
fits this alternative; it is not a closed zero-end construction.

### 4.1. A closed extension needs a nonparallel exterior

There is a global test of the proposed matching which does not require
extracting any cores. For the same weight-two solution on a closed
scalar-minus-four metric, the integrated spinor equation is

\[
 K:=\int|\nabla_A\Phi|^2=\int k(\rho),\qquad
 k(\rho)=\rho-\rho^2/2.
\]

Since \(|k'|\le1\) on \([0,2]\), (2.5) gives

\[
 \boxed{\frac{D_\beta}{V}\ge
 6\left|\frac KV-\frac49(1-\beta^{-1}-2\beta^{-2})\right|^2.}
 \tag{4.7}
\]

Thus a zero-end sequence must have \(K/V\to4/9\). For every fixed
split seed the whole shrinking construction ball, including the regions
between its selected components, has \(K=O_{d,b}(r^4)\) and curvature
energy \(O_{d,b}(r^4)\); its Hessian integral is \(O_{d,b}(r^2)\).
This follows by differentiating the smooth rescaled seed and choosing
the actual perturbation radius after \((d,b)\), as in X07. A diagonal
can make these costs negligible. Any closed extension with the required
volume normalization must therefore put \((4/9+o(1))V\) kinetic
energy in the exterior. A proposed nearly parallel exterior with
\(K/V\to0\) instead has \(\liminf D_\beta/V\ge32/27\).

This matching assertion assumes the closed scalar-minus-four extension
actually retains the displayed local solution. A conformal reduction of
some other proposed extension need not preserve its hyperbolic cores.

The harmonic data give another necessary exterior requirement. Under the
class-square condition, the topological saturation already proved in
[I41, Section 6](20260927_conformal_separation_and_zero_end.md) gives
\((a^2-T_+)/V\to0\) on the hypothetical zero-end sequence. This
statement concerns the class and metric and does not identify its earlier
weighted solution with the present one. Chern--Weil gives
\(T_+/V\to1/(6\pi^2)\), while (2.5) gives
\(\int|F_A^+|^2/V\to8/9\). Hence

\[
 \frac{\|H_A^+\|_2^2}{V}\to\frac89,\qquad
 \frac{\|H_A^-\|_2^2}{V}\to\frac29,
 \tag{4.8}
\]

using the same-class harmonic remainder (2.11). The shrinking construction
ball cannot carry these volume-scale harmonic energies: its actual
curvature energy and the global harmonic remainder are both negligible
at that scale. The exterior must supply them. It is not enough to glue
the displayed local zero sets into a metrically convenient region.

These are necessary matching tests, not an exclusion of every exterior.
A nonparallel bulk with \(K/V\to4/9\) and the harmonic data (4.8)
is not contradicted by these identities. Its construction or exclusion,
including the original same-class conformal solvability, remains open.

## 5. The balanced first-order target must retain curvature cancellation

Return to the **ordinary**, unscaled solution used in I50 Section 4 on the
balanced family. This section does not substitute the weight-two field of
Section 2 into ordinary-solution identities. Retain
\(\rho\le4\), \(\chi\), \(q_\chi\), \(B_o\), \(J\), \(M_\chi\),
and \(P_o\) from that section. Put

\[
 f=1-\chi,\quad u=\Phi/\sqrt\rho,\quad
 \mathbb F=F^{S^+},\quad C_\pm=\mathbb F^\pm u,
\]
\[
 X_\pm=\int f|C_\pm|^2,\qquad
 Y_\pm=\int f\operatorname{Re}\langle C_\pm,F_A^\pm u\rangle.
 \tag{5.1}
\]

The weighted expressions extend by zero near the spinor zero set. In a
unitary frame whose first vector is \(u\), write
\(\mathbb F^-=\left(\begin{smallmatrix}i\alpha&-\overline b\\
b&i\delta\end{smallmatrix}\right)\). Then

\[
 |\operatorname{Ric}^{\circ}|^2
 =2|\alpha-\delta|^2+8|b|^2,\qquad
 |F_A^-|^2=|\alpha+\delta|^2.
\]

Expanding both sides proves

\[
 \boxed{P_o-2B_o=8(X_--Y_-),\qquad
 |Y_-|\le\sqrt{X_-B_o}.}
 \tag{5.2}
\]

Consequently the existing spatial balance becomes exactly

\[
 P-8\pi^2Ah=8\left[X_--Y_--4\pi^2q_\chi+
             \pi^2(p-A)+J/4+M_\chi/4\right].
 \tag{5.3}
\]

A sufficient joint target for coefficient four is
\([Y_--X_-+4\pi^2q_\chi]_+=o(Ah)\). In particular,
\(X_-=o(Ah)\) and \((q_\chi)_+=o(Ah)\) would suffice, since
\(B_o=O(Ah)\). Unlike demanding \(B_o=o(Ah)\), this permits a
nonzero ASD determinant field annihilating the actual spinor.

There is no automatic new sign: the same rank-two Chern identity gives

\[
 4\pi^2q_\chi=(X_--Y_-)-(X_+-Y_+),\qquad
 Y_--X_-+4\pi^2q_\chi=Y_+-X_+.
 \tag{5.4}
\]

Thus the coupled criterion is an exact reformulation of the surviving
signed defect, not an independently proved positive estimate.

### 5.1. The same ordinary solution only has an order-Ah bound

Let \(\Pi=\nabla_A\Phi\), \(K=\int|\Pi|^2\), and \(D=D_2\).
Use the polynomial model from the ordinary remainder with
\(s_b=-4\), \(\operatorname{Ric}_b^\circ=0\), \(W_b^+=W_0\),
\(F_{A,b}^+=i\sigma(\Phi)\), \(F_{A,b}^-=0\).
Its curvature-action coefficients factor as

\[
 \rho^2/24+1/3-\rho/4=(\rho-2)(\rho-4)/24,
 \quad \rho^2/48-1/3=(\rho-4)(\rho+4)/48.
\]

The actual remainder bounds therefore imply
\(\int|\mathbb F_b\Phi|^2\le CD\) and
\(\int|\mathbb F-\mathbb F_b|^2\le C(P+B+D)\).
Apply the exact Hessian identity of I40 Section 4.1 to this ordinary
solution. Its bounded background terms cost \(CK\); its error terms
cost \(C\sqrt{P+B+D}\|\Pi\|_4^2\). The bounded-section interpolation
\(\|\Pi\|_4^2\le8\|\nabla_A^2\Phi\|_2\), followed by Young,
gives

\[
 \int(|\nabla_A^2\Phi|^2+|\nabla_A\Phi|^4)
                  \le C(K+P+B+D).
 \tag{5.5}
\]

On the balanced \(\mathcal E=O(h)\) sequences, the right side and
\(X_-\) are \(O(Ah)\), not \(o(Ah)\).

The remaining signed interaction can be written without an abstract
regularity assumption. Set
\(\mathcal J_3=\operatorname{Re}\langle\Pi\wedge\mathbb F\Phi\rangle\),
\(\mathcal C_4=\operatorname{Re}\langle\Pi\wedge\mathbb F\wedge\Pi\rangle\),
with conjugation in the first Hermitian factor. Covariant differentiation
and Bianchi give

\[
 d\mathcal J_3=(|\mathbb F^+\Phi|^2-|\mathbb F^-\Phi|^2)d\mu
                          -\mathcal C_4.
\]

Integrate against \(w_0=f/\rho\), extended smoothly by zero:

\[
 X_-=\int w_0|\mathbb F^+\Phi|^2-
           \int w_0\mathcal C_4+\int dw_0\wedge\mathcal J_3.
 \tag{5.6}
\]

The first term is \(O(D)\). After subtracting the model, the critical
interaction is bounded by
\(C\|\mathbb F-\mathbb F_b\|_2\|\Pi\|_4^2=O(Ah)\).
The cutoff current is likewise \(O(Ah)\). Taking absolute values
therefore does not prove the required smaller signed remainder.

For an exact negative cscK canonical ordinary solution, \(\rho=4\),
\(\nabla_A\Phi=0\), \(C_\pm=0\), and \(\chi=q_\chi=0\).
Equation (5.2) correctly gives \(P=2B\), even when \(B\ne0\).
This is why its cancellation must be retained. No transfer of this
observation to a whole balanced handle-and-blowup recovery sequence is
asserted without matching the actual solutions.

## 6. The remaining global implication

The endpoint problem now has an exact constant-scalar, constant-weight
form with small determinant Hodge graph error. Its unresolved source is
not an auxiliary weight derivative. It is the critical coupling of the
torsion derivative, the actual curvature, and signed transition flux.

High-index cores cannot be excluded by their listed subcritical costs;
their controlled extensions satisfy the explicit alternative (3.8).
Splitting the zeros avoids treating the monomial's superlinear cost as
universal. Neither model supplies the closed exterior, the global square
condition, or the same-class conformal supplier required by O10.

For the balanced problem, (5.3)--(5.6) locate the order-Ah signed term
without discarding the parallel-core cancellation. Its little-o estimate
or a lower-coefficient actual recovery construction is still required.
These are the two continuing global tests; the new identities do not
replace them by a completed defect-decomposition or realization theorem.


END COMPLETE SOURCE
