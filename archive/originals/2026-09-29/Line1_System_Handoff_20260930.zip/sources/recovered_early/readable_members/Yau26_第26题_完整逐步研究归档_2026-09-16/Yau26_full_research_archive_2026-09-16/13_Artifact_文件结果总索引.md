# 13 Artifact / 文件结果总索引

说明：`not mounted` / `File Library only` 表示当前 ChatGPT sandbox 没有原始 raw bytes。本 ZIP 不伪装成已复制，而是完整保存路径、用途、状态与可追溯关系。

|类别|路径/文件|作用|状态|当前可打包性|
|---|---|---|---|---|
|Governing|Skills/qiushi-yau26/references/research/20260910.tex|原始框架/早期四维估计|research dossier|not mounted|
|Governing|Skills/qiushi-yau26/references/research/20260912.tex|6558-line cumulative manuscript|research source; not proof|not mounted|
|IL core|workspace/notes/step3_mixed_bound_analysis.md|mixed SW bound|repaired/canonical|not mounted|
|IL core|workspace/notes/step4_near_equality_and_boundary_calibration.md|near-equality|repaired/canonical|not mounted|
|IL core|workspace/notes/step5_curvature_ratio_and_rigidity.md|curvature ratio|research|not mounted|
|IL core|workspace/notes/step8_derdzinski_measure_local_theorem.md|Derdzinski/density|canonical|not mounted|
|Source|workspace/data/sources/derdzinski_1983_self_dual_kahler_einstein_four.pdf|primary source|source|not mounted|
|IL assembly|workspace/notes/step68_restricted_IL_canonical_assembly.md|restricted assembly|conditional; read with 69–72 repairs|not mounted|
|IL assembly|workspace/notes/step67_terminal_recalibration_recovery.md|terminal recalibration|strong internal|not mounted|
|IL assembly|workspace/notes/step65_per_datum_existence_theorem.md|per-datum flow|conditional|not mounted|
|Support|workspace/notes/step70_selected_support_lemma.md|selected support|internal|not mounted|
|Moser|workspace/notes/step70_defect_moser_real_exponent.md|real-exponent Moser|internal|not mounted|
|Moser|workspace/notes/step62_defect_moser_general_p_proof.md|general-p Moser|internal|not mounted|
|Flow|workspace/notes/step55_joint_bootstrap_background_continuation_repair.md|bootstrap repair|internal|not mounted|
|Flow|workspace/notes/step63_curvature_variation_index_proof.md|curvature variation|internal|not mounted|
|Flow|workspace/notes/step64_convention_consistency_sweep.md|convention sweep|internal|not mounted|
|Flow|workspace/notes/step59_induction_ledger_repair.md|induction ledger|internal|not mounted|
|Flow|workspace/notes/step60_base_pair_proof.md|base pair|internal|not mounted|
|Flow|workspace/notes/step50_normalized_yang_wang_verification.md|source-normalized flow|source audit|not mounted|
|Flow|workspace/notes/step52_normalized_local_flow_start_repair.md|start repair|internal|not mounted|
|Flow|workspace/notes/step54_exact_synchronized_output_ledger.md|output ledger|internal|not mounted|
|Flow|workspace/notes/step56_tame_direct_flow_repair.md|tame repair|internal|not mounted|
|Flow|workspace/notes/step56_positive_time_base_pair.md|positive-time base|internal|not mounted|
|Flow|workspace/notes/step57_H2_evolution_and_continuation_bridge.md|H2 bridge|internal|not mounted|
|Flow|workspace/notes/step58_critical_to_subcritical_bridge.md|critical-subcritical|internal|not mounted|
|Flow|workspace/notes/step60_all_order_continuation_and_terminal_chart.md|all-order/terminal chart|internal|not mounted|
|Check|workspace/scripts/step56_tame_allocation_check.py|14,002,305 allocation checks|computational|not mounted|
|Check|workspace/scripts/step58_critical_subcritical_verify.py|54/54 checks|computational|not mounted|
|Check|workspace/scripts/step60_family_enumeration_verify.py|252,256 allocations/order64|computational|not mounted|
|Graph|workspace/notes/step63_graph_manifold_counterexample_analysis.md|graph route|research|not mounted|
|Graph|workspace/notes/step63_matching_problem_formulation.md|matching|research|not mounted|
|Graph|workspace/notes/step64_margin_and_route_assessment.md|margin/route|research|not mounted|
|Graph|workspace/notes/step65_mu4_correction_and_neck_fusion.md|mu4/neck|research|not mounted|
|Graph|workspace/notes/step67_corrections_and_analytic_neck_reopening.md|graph reopening|research|not mounted|
|Graph|workspace/notes/step69_anisotropic_cusp_compensation.md|q_N construction|strong computational/theoretical|not mounted|
|Graph|workspace/scripts/step69_collapsed_koiso_center.py|Yamabe/center|numerical|not mounted|
|Graph|workspace/data/step69_collapsed_koiso_center.json|center data|numerical|not mounted|
|Graph|workspace/scripts/step69_koiso_galerkin.py|Einstein Cauchy Galerkin|numerical|not mounted|
|Graph|workspace/data/step69_koiso_galerkin.json|Galerkin data|numerical|not mounted|
|Graph|workspace/notes/step72_graph_neck_weighted_shear_budget.md|weighted shear|research|not mounted|
|Graph|workspace/notes/step74_graph_center_and_positive_flux_rebalance.md|center/flux|research|not mounted|
|Late graph|workspace/notes/step94_charge_sign_correction_and_global_flux.md|charge/global flux|research|not mounted|
|Late graph|workspace/notes/step95_KX_and_bochner_cancellation.md|KX/Bochner|research|not mounted|
|Late graph|workspace/notes/step96_charged_koiso_local_evolution_and_joint_matching.md|charged Koiso|research|not mounted|
|Late graph|workspace/notes/step98_full_matrix_matching_pressure_test.md|full matrix|computational/research|not mounted|
|Late graph|workspace/notes/step99_raychaudhuri_cgb_and_cost_structure.md|Raychaudhuri/CGB|research|not mounted|
|Positive|workspace/notes/step30_route_reassessment_noncollapsed_bubble_variational.md|positive noncollapsed|research|not mounted|
|Positive|workspace/data/step30_noncollapsed_bubble_variational_audit.json|EH audit|computational|not mounted|
|Positive|workspace/notes/step83_near_pinched_construction_and_frontier_reduction.md|near-pinched product orbifold|conditional|not mounted|
|Positive|workspace/notes/step98_trace_obstruction_theorem.md|chirality trace|finite-order/conditional|not mounted|
|Lean|workspace/scripts/step89_relative_green_algebra.lean|odd-odd sign identity|narrow formal|not mounted|
|Lean|Sessions/S0910A02/workspace/proofs/Step99RealLinearPQ.lean|real-linear determinant|narrow formal|not mounted|
|FileLibrary|meta_trace_report (93)(1).md|100-step trace branch|primary trace|File Library only|
|FileLibrary|meta_trace_report (94)(1).md|100-step trace branch|primary trace|File Library only|
|FileLibrary|meta_trace_report (95)(1).md|100-step trace branch|primary trace|File Library only|
|FileLibrary|Yau26_Ricci_pinching_research.md|cumulative detailed research|research source|File Library only|
|FileLibrary|Yau26_synthesis.tex|synthesis source|research source|File Library only|
|FileLibrary|Yau26_synthesis.pdf|compiled synthesis|research source|File Library only|
